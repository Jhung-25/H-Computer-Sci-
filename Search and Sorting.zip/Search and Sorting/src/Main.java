
public class Main {
    public static void main(String[] args) {
        int[]arr = new int[]{1,2,3,4,5};
        System.out.println(sequentialSearch(4,arr));

    }
    public static int sequentialSearch(int tarNum, int[]arr){
        for(int i=0;i<arr.length;i++){
            if(arr[i]==tarNum){
                return i;
            }
        }

        return -1;
    }
}